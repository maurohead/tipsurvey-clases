<?php

namespace Curso\SurveyBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AnswerType
 *
 * @ORM\Table(name="tipsurvey_answertype")
 * @ORM\Entity
 */
class AnswerType
{
	/**
	 *
	 * @ORM\Column(name="id", type="smallint", nullable=false)
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="IDENTITY")
	 */
	
     private $id;
 
 
     /**
      * @ORM\Column(name="etiqueta", type="string", length=255, nullable=false)
      *
      */
      private $etiqueta;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set etiqueta
     *
     * @param string $etiqueta
     * @return AnswerType
     */
    public function setEtiqueta($etiqueta)
    {
        $this->etiqueta = $etiqueta;
    
        return $this;
    }

    /**
     * Get etiqueta
     *
     * @return string 
     */
    public function getEtiqueta()
    {
        return $this->etiqueta;
    }
}